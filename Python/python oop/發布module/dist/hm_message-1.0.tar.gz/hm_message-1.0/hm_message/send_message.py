def send(text):
    print("正在發送 %s..." % text)