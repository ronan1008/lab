def receive():
    return "這是來自100xx訊息"